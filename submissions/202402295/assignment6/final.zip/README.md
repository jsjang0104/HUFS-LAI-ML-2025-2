
---

# 실행 방법

## 1. 압축 해제

`final.zip` 파일의 압축을 해제합니다.

---

## 2. 터미널에서 프로젝트 폴더로 이동

터미널(cmd 또는 PowerShell)을 열고 압축을 푼 폴더로 이동합니다.

**예시 (Windows):**

```bash
cd ~~~\final
```

---

## 3. 라이브러리 설치

필요한 라이브러리를 설치합니다.

```bash
pip install -r requirements.txt
```

만약 `pip`가 인식되지 않는 경우:

```bash
py -m pip install -r requirements.txt
```

---

## 4. 디스코드 Webhook URL 설정

`news_to_discord.py` 파일을 열고 아래 부분에 본인의 디스코드 웹훅 URL을 입력합니다.

```python
WEBHOOK_URL = "여기에_자신의_디스코드_웹훅_URL"
```

---

## 5. 프로그램 실행

아래 명령어를 실행합니다.

```bash
python news_to_discord.py
```

또는

```bash
py news_to_discord.py
```

---

## 6. 실행 결과 확인

정상 실행 시 디스코드 채널에 추천 뉴스가 자동으로 전송됩니다.

실패 시 터미널에 오류 메시지가 출력됩니다.

---

## 7. 주의 사항

* RSS 서버 상태에 따라 뉴스가 수집되지 않을 수 있습니다.
* `news_model.pth`, `tfidf.pkl` 파일은 반드시 실행 파일과 같은 폴더에 있어야 합니다.
* Webhook URL은 외부에 공개하지 마십시오.