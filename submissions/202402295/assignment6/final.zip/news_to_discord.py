import torch
import torch.nn as nn
import torch.nn.functional as F
import joblib
import requests
import feedparser
import numpy as np
import re
import html

#############################
# 1. 디스코드 웹훅
#############################
WEBHOOK_URL = "연결할_디스코드_웹훅_URL"

#############################
# 2. 모델 로드
#############################
VECTOR_PATH = "tfidf.pkl"
MODEL_PATH = "news_model.pth"

vectorizer = joblib.load(VECTOR_PATH)

class NewsClassifier(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, 256)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.3)
        self.fc2 = nn.Linear(256, 2)

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        return self.fc2(x)

model = NewsClassifier(input_dim=vectorizer.max_features)
model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu"))
model.eval()

#############################
# 3. Discord 전송
#############################
def send_to_discord(msg):
    requests.post(WEBHOOK_URL, json={"content": msg})

#############################
# 4. 뉴스 수집
#############################
def clean_html(text):
    text = html.unescape(text)   # &nbsp; 같은 HTML 엔티티 제거
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\s+', ' ', text)  # 공백 정리
    return text.strip()

def fetch_news():
    url = "https://news.google.com/rss?hl=ko&gl=KR&ceid=KR:ko"
    feed = feedparser.parse(url)

    if not feed.entries:
        send_to_discord("❌ 뉴스 수집 실패: RSS에서 데이터를 받아오지 못했습니다.")
        return []

    news = []

    for e in feed.entries[:20]: # 최신 뉴스 20개
        title = e.title
        link = e.link
        summary = clean_html(e.summary) if 'summary' in e else ""

        full_text = title + " " + summary

        news.append({
            "title": title,
            "summary": summary,
            "text": full_text,
            "link": link
        })

    return news

#############################
# 5. 예측 (확률 기반)
#############################
def predict_probs(text_list):
    X_vec = vectorizer.transform(text_list).toarray()
    X = torch.tensor(X_vec, dtype=torch.float32)

    with torch.no_grad():
        outputs = model(X)
        probs = F.softmax(outputs, dim=1)
        interest_probs = probs[:, 1].numpy()

    return interest_probs

#############################
# 6. 추천 필터링
#############################
def run_service():
    news = fetch_news()

    if not news:
        print("뉴스 없음 - 종료")
        return

    texts = [n["text"] for n in news]

    probs = predict_probs(texts)

    # 확률 붙이기
    for i in range(len(news)):
        news[i]["prob"] = probs[i]

    #  확률 0.6 이상 필터링
    filtered = [n for n in news if n["prob"] >= 0.6]

    #  확률 기준 정렬
    filtered = sorted(filtered, key=lambda x: x["prob"], reverse=True)

    #  상위 5개
    final = filtered[:5]

    if not final:
        send_to_discord("✅ 오늘 추천할 뉴스가 없습니다.")
        return

    send_to_discord("🔥 **오늘의 추천 뉴스 (확률 기반)**")

    for n in final:
        msg = f"""📰 **{n['title']}**
📊 관심 확률: {n['prob']:.2f}
{n['summary'][:150]}...
🔗 {n['link']}
"""
        send_to_discord(msg)

    send_to_discord("✅ 추천 완료!")

#############################
# 실행
#############################
if __name__ == "__main__":
    run_service()
